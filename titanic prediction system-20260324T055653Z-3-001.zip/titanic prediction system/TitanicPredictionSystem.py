


import streamlit as st
import pandas as pd
import joblib

# Load model and encoders
model = joblib.load('titanic_model.pkl')
le_sex = joblib.load('le_sex.pkl')
le_embarked = joblib.load('le_embarked.pkl')

st.title("Titanic Survival Prediction")

# User inputs
pclass = st.selectbox("Passenger Class (Pclass)", options=[1, 2, 3], index=2)
sex = st.selectbox("Sex", options=['male', 'female'])
age = st.number_input("Age", min_value=0, max_value=120, value=30)
fare = st.number_input("Fare", min_value=0.0, max_value=600.0, value=32.0)
embarked = st.selectbox("Embarked", options=['C', 'Q', 'S'], index=2)

# Encode inputs
sex_encoded = le_sex.transform([sex])[0]
embarked_encoded = le_embarked.transform([embarked])[0]

# Prepare input for model
input_df = pd.DataFrame([{
    'Pclass': pclass,
    'Sex': sex_encoded,
    'Age': age,
    'Fare': fare,
    'Embarked': embarked_encoded
}])

if st.button("Predict Survival"):
    pred = model.predict(input_df)[0]
    result = "Survived 🎉" if pred == 1 else "Did not survive 💔"
    st.success(result)

